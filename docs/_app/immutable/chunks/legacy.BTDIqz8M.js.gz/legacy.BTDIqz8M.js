import{am as a}from"./runtime.DKeJz3Sd.js";a();
